echo "enter two number"
read a
read b
div=$((a/b))
echo "quotient is:$div"
