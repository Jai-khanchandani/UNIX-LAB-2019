echo "Enter two numbers"
read a
read b
sub=$((a-b))
echo "sub:$sub"
