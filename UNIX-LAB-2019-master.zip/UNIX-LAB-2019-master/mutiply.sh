echo "Enter two numbers"
read a
read b
mul=$((a*b))
echo"multiplication:$mul"
