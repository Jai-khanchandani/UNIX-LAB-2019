echo "Enter two numbers"
read a
read b
sum=$((a+b))
echo "Sum is: $sum"
